require('dotenv').config();

module.exports = {
    database:{
        connectionLimit: 10,
        host: 'localhost',
        user: 'root',
        password: '1234',
        database:'grin'
    }
}
